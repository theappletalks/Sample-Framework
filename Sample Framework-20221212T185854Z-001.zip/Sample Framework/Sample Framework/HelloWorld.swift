//
//  HelloWorld.swift
//  Sample Framework
//
//  Created by Pulkit Vora on 12/12/22.
//

import Foundation

public class HelloWorld{
    public init(){}
    
    public func printMessage(messageString : String){
        print(messageString)
    }
}
